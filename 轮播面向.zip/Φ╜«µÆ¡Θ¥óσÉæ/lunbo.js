/**
 * Created by 吴猛龙 on 2016/9/14.
 */
//构造 函数
function scroll(id,opt){
    this.box=document.getElementById(id);
    this.boxW=opt.width;
    this.boxH=opt.height;
    this.list=opt.list;
    this.times=opt.times||3000;
    this.init();
    this.create();

}
//添加方法
scroll.prototype= {
    init:function(){ //初始化相关参数
        this.index=0;
    },
    create:function(){
        //创建dom,缓存相关数据
        var box=this.box;
        var w=this.boxW;
        var h=this.boxH;
        var list=this.list;
        //设置容器样式
        box.style.cssText='width:'+w+'px;height:'+h+'px;position:relative;';
        //创建滚动元素
        this.ball=document.createElement("ul");
        this.poiBox=document.createElement("div");
        this.poiBox.style.cssText='width:'+(20*list.length)+'px;height:16px;position:absolute;left:'+
            (w-20*list.length)/2+'px;bottom:10px;z-index:10;';
        //创建图片
        for (var i=0;i<list.length;i++) {
            //创建图片结构
            var cell = document.createElement("li");
            cell.style.cssText = 'width:' + w + 'px;height:' + h + 'px;list-style:none;';
            var oA = document.createElement("a");
            oA.href = list[i].href;
            oA.style.cssText = 'width:100%;height:100%;display:block;';
            var img = document.createElement("img");
            img.src = list[i].url;
            img.style.cssText = 'width:100%;height:100%;display:block;border:0;';
            //图片插入
            oA.appendChild(img);
            cell.appendChild(oA);
            this.ball.appendChild(cell);
            //创建point
            var points=document.createElement("span");
            points.index=i;
            points.style.cssText="display:inline-block;width:16px;height:16px;border-radius:50%;background-color:pink;margin-right:4px;opacity:0.3;filter:alpha(opacity=30);";
            if(i==0){
                points.style.opacity=1;
                points.style.filter='alpha(opacity=100)';
            }
            this.poiBox.appendChild(points)
        }
            //插入左右箭头
        this.prev=document.createElement('a');
        this.prev.href='javascript:void(0)';
        this.prev.innerHTML="&lt;";
        this.prev.style.cssText = 'display:block;position:absolute;font-size:30px;padding:10px 5px;background-color:rgba(0,0,0,0.5);left:0;top:'+(h-50)/2+'px;color:#ffffff;text-decoration:none;font-family:"黑体";';
         this.next=document.createElement('a');
        this.next.href='javascript:void(0)';
        this.next.innerHTML='&gt;';
        this.next.style.cssText='display:block;position:absolute;font-size:30px;padding:10px 5px;background-color:rgba(0,0,0,0.5);right:0;top:'+(h-50)/2+'px;color:#ffffff;text-decoration:none;font-family:"黑体";';
         //全部插入到父元素中；
            box.appendChild(this.ball);     ///插入顺序会影响层级 导致被覆盖显示不出来，下面就会被覆盖，只能再给prev,next加index
            box.appendChild(this.poiBox);
            box.appendChild(this.prev);
            box.appendChild(this.next);
        // box.appendChild(this.prev);
        // box.appendChild(this.next);
        // box.appendChild(this.poiBox);
        // box.appendChild(this.ball);
    },
    //dan ru danchu;
    fade:function () {
        var box=this.box;
        var ball=this.ball;
        var cell=ball.children;
        var poiBox=this.poiBox;
        var points=poiBox.children;
        var prev=this.prev;
        var next=this.next;
        ball.style.cssText = 'width:100%;height:100%;position:relative;';
       for(var i=0;i<cell.length;i++){
           cell[i].style.position = 'absolute';
           cell[i].style.left = 0;
           cell[i].style.top = 0;
           cell[i].style.opacity = 0;
           cell[i].style.filter = 'alpha(opacity=0)';
       }
        cell[0].style.opacity=1;
        cell[0].style.filter='alpha(opacity=100)';
        //添加自动轮播；
        this.timer=setTimeout(fade,this.times);
        var self=this; //>??????????
        var  flag=true;
        function  fade(){
            self.index++;
            if(self.index==cell.length){
                self.index=0;
            }
            for(var j = 0;j < cell.length;j++){
                animation(cell[j],'opacity',0);
                animation(points[j],'opacity',0.3);
            }
            //图片切换
            animation(cell[self.index],'opacity',1,function(){
                clearTimeout(self.timer);
                if(flag){
                    self.timer = setTimeout(fade,self.times);
                }
            })
            //焦点切换
            animation(points[self.index],'opacity',1);
        }
        box.onmouseover=function () {
            flag=false;
            prev.style.display="block";
            next.style.display="block";
            clearTimeout(self.timer);
        }
        box.onmouseout=function () {
            flag=true;
            prev.style.display="none";
            next.style.display="none";
            self.timer=setTimeout(fade,self.times)  /////////
        }
        //焦点切换
        poiBox.onclick=function (event) {
            var e=window.event||event;
            var obj=e.target?e.target:e.srcElement;   //>>???????????
            if(obj.nodeName.toLowerCase()=='span'){   //>????????
                self.index=obj.index;
                for(var j = 0;j < cell.length;j++){
                    animation(cell[j],'opacity',0);
                    animation(points[j],'opacity',0.3);
                }
                //图片切换
                animation(cell[self.index],'opacity',1)
                //焦点切换
                animation(obj,'opacity',1);
            }
        }
        //左右切换
            prev.onclick = function(){
                self.index--;
                if(self.index==-1){
                    self.index = cell.length-1;
                }
                for(var j = 0;j < cell.length;j++){
                    animation(cell[j],'opacity',0);
                    animation(points[j],'opacity',0.3);
                }
                //图片切换
                animation(cell[self.index],'opacity',1)
                //焦点切换
                animation(points[self.index],'opacity',1);
            }
            next.onclick=fade; //////
    },
     move:function () {
         var box = this.box;
         var ball = this.ball;
         var cell = ball.children;
         var poiBox = this.poiBox;
         var points = poiBox.children;
         var prev = this.prev;
         var next = this.next;
         var list = this.list;
         var w = this.boxW;
         //完善布局
         box.style.overflow = 'hidden';
         ball.style.cssText = 'width:'+(list.length + 1)*w+'px;overflow:hidden;position:absolute;left:0;top:0;';
         for(var i = 0;i < cell.length;i++){
             cell[i].style.float = 'left';
         }
         var  first=cell[0].cloneNode(true);
         ball.appendChild(first);
         //自动轮播
         var self = this;
         console.log(self)
         var flag = true;
         this.timer = setTimeout(move,this.times)
         function  move(){
             self.index--;
             if(self.index==-cell.length){
                  self.index=-1;  //起始是0，每次－1，到达长度后回转，因为插入了一张克隆的图，所以变成-1；
                 ball.style.left=0;
             }
             for(var j = 0;j < list.length;j++){
                 animation(points[j],'opacity',0.3);
             }
             animation(ball,'left',w * self.index,function(){
                 clearTimeout(self.timer);
                 if(flag){
                     self.timer = setTimeout(move,self.times);
                 }
             })
             animation(points[-self.index%list.length],'opacity',1); //////////////////////////////////
         }
         //鼠标划入停止
         box.onmouseover = function(){
             flag = false;
             prev.style.display = 'block';
             next.style.display = 'block';
             clearTimeout(self.timer);
         }
         //鼠标滑出继续轮播
         box.onmouseout = function(){
             flag = true;
             prev.style.display = 'none';
             next.style.display = 'none';
             self.timer = setTimeout(move,self.times);
         }
         //焦点切换
         poiBox.onclick = function(event) {
             var e = event || window.event;
             var obj = e.target ? e.target : e.srcElement;
             console.log(obj)
             if (obj.nodeName.toLowerCase() == 'span') {

                 for (var j = 0; j < list.length; j++) {
                     animation(points[j], 'opacity', 0.3);
                 }

                 if (obj.index == 0 && self.index == -list.length) {
                     ball.style.left = 0;                ////////////////
                 }

                 self.index = -obj.index; /////////////////////
                 //图片切换
                 animation(ball, 'left', w * self.index)
                 //焦点切换
                 animation(obj, 'opacity', 1);
             }
         }
         //左右切换
         prev.onclick = function(){
             self.index++;
             if(self.index==1){
                 self.index = -list.length+1;
                 ball.style.left = -list.length * w + 'px';
             }
             for(var j = 0;j < list.length;j++){
                 animation(points[j],'opacity',0.3);
             }
             //图片切换
             animation(ball,'left',w * self.index)
             //焦点切换
             animation(points[-self.index%list.length],'opacity',1);
         }
         next.onclick = move;
     }

}