//构造函数

function snow(opt){
	this.url = opt.url;
	this.box = document.getElementById(opt.id);
	this.times = opt.times||100;
	this.fx = opt.fx||1;

	this.init();
	this.loop();
}

//添加原型方法
snow.prototype = {
	//初始化参数
	init:function(){
		this.boxW = this.box.clientWidth;
		this.boxH = this.box.clientHeight;
	},
	//准备dom元素
	create:function(){
		var w = this.boxW;
		var h = this.boxH;
		var url = this.url;
		var box = this.box;
		var cell = document.createElement('div');
		console.log(cell);
		cell.size = Math.floor(Math.random()*21+20);
		cell.l = Math.floor(Math.random()*(w - cell.size));
		cell.style.cssText = 'width:'+cell.size+'px;height:'+cell.size+'px;background:url('+url+') center no-repeat;background-size:100% 100%;left:'+cell.l+'px;'
		box.appendChild(cell);
		cell.t = 0;
		cell.sl = Math.floor(Math.random()*5+1)*this.fx;
		cell.st = Math.floor(Math.random()*5+1);
		cell.timer = setInterval(function(){
			cell.l += cell.sl;
			cell.t += cell.st;

			if(cell.t>=h - cell.size||cell.l<=0||cell.l>=w-cell.size){
				clearInterval(cell.timer);
				box.removeChild(cell)
			}

			cell.style.left = cell.l + 'px';
			cell.style.top = cell.t + 'px';
		},10)
	},
	//循环调用
	loop:function(){
		var self = this;
		this.timer = setInterval(function(){
			self.create();
		},this.times);
	}
}