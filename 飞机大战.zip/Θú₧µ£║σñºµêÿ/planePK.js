/**
 * Created by ice on 2016/9/18.
 */
//创建容器
function bag(){
    this.box=document.getElementById("box")
}
function myPlane(blood){
    bag.call(this)                  ///////获取上面的盒子 装X的写法
    this.blood=blood;
    //console.log(this.box)
    this.init();
    this.create();
    this.move();
}
myPlane.prototype={
    init:function () {
      this.boxW=this.box.clientWidth;
       this.boxH=this.box.clientHeight;
        this.pos={
            x:157,
            y:474
        }
    },
    //
    create:function () {
      var box=this.box; ///////
       this.plane=document.createElement("div");
       this.plane.className="myplane";
        this.plane.b=this.blood;
        this.box.appendChild(this.plane)
    },
    move:function(){
        var plane=this.plane;
        var w=this.boxW;
        var h=this.boxH;
        var self=this;
      box.onmousemove=function (event) {
          var e=window.event||event;
          var oLeft=(e.offsetX||e.layerX)-plane.offsetWidth/2;
          var oTop=(e.offsetY||e.layerY)-plane.offsetHeight/2;
          // if(oLeft>w-plane.offsetWidth/2){
          //     oLeft=w-plane.offsetWidth/2;
          // }
          // else if(oLeft<0){
          //     oLeft=0;
          // }
          // if(oTop>h-plane.offsetHeight){
          //     oTop=h-plane.offsetHeight;
          // }else if(oTop<0){
          //     oTop=0;
          // }
          if(oLeft <= - plane.offsetWidth/2){
              oLeft = - plane.offsetWidth/2
          }else if(oLeft >= w - plane.offsetWidth/2){
              oLeft = w - plane.offsetWidth/2
          }
          self.pos.x=oLeft+plane.offsetWidth/2;
          self.pos.y=oTop;
          plane.style.left=oLeft+"px";
          plane.style.top=oTop+"px";
      }
    }
}
//构建 子弹的函数
 function Bullet(_spacing){
     bag.call(this)
     this.spacing=_spacing;
     this.loop();
 }
 //添加方法
 Bullet.prototype= {
     // create:function() {
     //     var box=this.box;
     //     var bullet=document.createElement("span");
     //     bullet.className="bullet";
     //     //初始化 子弹的位置  算是动态创建的吧  因为根据上面的移动的位置定义的
     //     bullet.style.left=(plane.pos.x-3)+"px";
     //     bullet.style.top=(plane.pos.y-14)+"px"
     //     box.appendChild(bullet);
     //     //设置子弹的变化量
     //     bullet.t=(plane.pos.y-14);       ///////////
     //     bullet.timer=setInterval(function () {
     //         bullet.t-=5;
     //         if(bullet.t<=0){
     //             clearInterval(bullet.timer);
     //             box.removeChild(bullet);
     //         }
     //         bullet.style.top=bullet.t+"px";
     //     },10)
     create:function() {
         var box=this.box;
         var bullet=document.createElement("span");
         var bulletleft=document.createElement("span");
         var bulletright=document.createElement("span");
         bulletright.className="bulletright";
         bulletleft.className="bulletleft"
         bullet.className="bullet";
         //初始化 子弹的位置  算是动态创建的吧  因为根据上面的移动的位置定义的
         bullet.style.left=(plane.pos.x-3)+"px";
         bullet.style.top=(plane.pos.y-14)+"px"
         bulletleft.style.left=(plane.pos.x-30)+"px";
         bulletleft.style.top=(plane.pos.y-7)+"px";
         bulletright.style.left=(plane.pos.x+30)+"px";
         bulletright.style.top=(plane.pos.y-7)+"px"
         box.appendChild(bullet);
         box.appendChild(bulletleft);
         box.appendChild(bulletright);
         //设置子弹的变化量
         bullet.t=(plane.pos.y-14);       ///////////
         bullet.timer=setInterval(function () {
             bullet.t-=5;
             if(bullet.t<=0){
                 clearInterval(bullet.timer);
                 box.removeChild(bullet);
             }
             bullet.style.top=bullet.t+"px";
         },10)
         bulletleft.t=(plane.pos.y-14);       ///////////
         bulletleft.timer=setInterval(function () {
             bulletleft.t-=5;
             if(bulletleft.t<=0){
                 clearInterval(bulletleft.timer);
                 box.removeChild(bulletleft);
             }
             bulletleft.style.top=bulletleft.t+"px";
         },10)
         bulletright.t=(plane.pos.y-14);       ///////////
         bulletright.timer=setInterval(function () {
             bulletright.t-=5;
             if(bulletright.t<=0){
                 clearInterval(bulletright.timer);
                 box.removeChild(bulletright);
             }
             bulletright.style.top=bulletright.t+"px";
         },10)
     },
     loop:function(){
         var self=this;
         //console.log(self)    //结果是 Bullet
         this.timer=setInterval(function () {
             self.create();
             //console.log(this);   //结果是 WINDOW
         },this.spacing) //////////////////////// 套路 重复循环 创建子弹
     }
 }
 //创建敌机
 function  elePlane(speed,blood,spacing,start,over){
     bag.call(this);
     this.blood=blood;
     this.speed=speed;
     this.spacing=spacing;
     this.start=start;
     this.over=over;
     this.init();
     this.loop();
 }
elePlane.prototype= {
    init: function () {
        this.boxW = this.box.clientWidth;
        this.boxH = this.box.clientHeight;
    },
    create: function () {
        var box = this.box;
        var w = this.boxW;
        var h = this.boxH;
        var b = this.blood;
        var speed = this.speed;
        var start = this.start;
        var over = this.over;
        //
        var eleP1 = document.createElement("div");
        eleP1.className = start;
        box.appendChild(eleP1);
        eleP1.style.left = Math.floor(Math.random() * w-(eleP1.offsetWidth)) + "px" ////////////获取敌机的位置

        eleP1.b = b
        eleP1.t = eleP1.offsetTop;
       // console.log(eleP1.t)
        eleP1.l = eleP1.offsetLeft;
        eleP1.w = eleP1.offsetWidth;             //////////////////////////方便后面的写入
        eleP1.h = eleP1.offsetHeight;
        var self = this;
        eleP1.timer=setInterval(function(){
            eleP1.t+=speed; ///往下降
            if(eleP1.t>=h-eleP1.offsetHeight){
                clearInterval(eleP1.timer);
                box.removeChild(eleP1);
            }
            var bullets=box.getElementsByTagName("span");
            for(var i=0;i<bullets.length;i++){
                var a=bullets[i]
                if((eleP1.t+eleP1.h>=a.t&&a.t+a.offsetHeight>=eleP1.t)&&(eleP1.l+eleP1.w>=a.offsetLeft&&a.offsetLeft+a.offsetWidth>=eleP1.l)){
                    eleP1.b--;
                    clearInterval(a.timer);
                    box.removeChild(a);
                    if(eleP1.b==0){
                        eleP1.className=over;
                        clearInterval(eleP1.timer);
                        setTimeout(function(){
                            box.removeChild(eleP1);
                        },500)
                    }
                }
            }
         var myp=plane.plane;       ///////////
          if((eleP1.l+eleP1.w>=myp.offsetLeft&&myp.offsetLeft+myp.offsetWidth>=eleP1.l)&&(eleP1.t+eleP1.h>=myp.offsetTop&&
              myp.offsetTop+myp.offsetHeight>=eleP1.t)){
              myp.b--;
            //
              eleP1.b=0;
              eleP1.className=over;
              clearInterval(eleP1.timer);
              setTimeout(function(){
                  box.removeChild(eleP1);
              },500)
              if(myp.b==0){
                  myp.className="boom";
                  box.onmousemove=null;
                  clearInterval(bullet.timer);
                  clearInterval(eleP1.timer);
                  clearInterval(elePP1.timer);
                  clearInterval(elePP2.timer);
                  setTimeout(function(){
                      box.removeChild(myp);
                      var isCon=confirm("again?");
                      if(isCon){
                        window.location.reload();
                      }else{
                          window.close();
                      }
                  },500)
              }
          }
          eleP1.style.top=eleP1.t+"px";
        },10)

    },
    loop:function(){
        var self=this;
        this.timer=setInterval(function(){
            self.create();
        },this.spacing)
    }
}
// function godpresent(speed,spacing,start){
//   bag.call(this);
//     this.speed=speed;
//     this.spacing=spacing;
//     this.start=start;
//     this.init();
//      this.create();
//       this.loop();
// }
// godpresent.prototype={
//     init:function(){
//         this.boxW = this.box.clientWidth;
//         this.boxH = this.box.clientHeight;
// },
//     create:function () {
//         var box=this.box;
//          var w=this.boxW;
//          var h=this.boxH;
//          var speed=this.speed;
//          //console.log(speed)
//         var start=this.start;
//         var pres=document.createElement("div");
//         pres.className=start;
//         box.appendChild(pres);
//         pres.style.left = Math.floor(Math.random() * (w-pres.offsetWidth)) + "px";
//         pres.l=pres.offsetLeft;
//         pres.t=pres.offsetTop;
//         pres.w=pres.offsetWidth;
//         pres.h=pres.offsetHeight;
//         var myp=plane.plane;
//         pres.timer=setInterval(function () {
//             pres.t+=speed;
//             //console.log(pres.t)
//             if(pres.t>h-pres.offsetHeight){
//                 clearInterval(pres.timer);
//                 box.removeChild(pres);
//             }
//                 if((pres.t+pres.h>=myp.offsetTop&&myp.offsetTop+myp.offsetHeight>=pres.t)&&(pres.l+pres.w>=myp.offsetLeft&&myp.offsetLeft+myp.offsetWidth>=pres.l)){
//                     clearInterval(pres.timer);   //
//                     setTimeout(function () {
//                        box.removeChild(pres);
//
//                     },500)
//                 }
//             pres.style.top=pres.t+"px";
//         },10)
//     },
//     loop:function () {
//         var self=this;
//         this.timer=setInterval(function () {
//             self.create();
//         },this.spacing)
//     }
//}


